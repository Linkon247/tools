
import React, { useState, useCallback, useEffect } from 'react';
import { ImageFile } from '@/types';
import { generateImageMetadata } from '@/services/geminiService';
import ImageUploader from '@/components/ImageUploader';
import MetadataDisplay from '@/components/MetadataDisplay';
import Loader from '@/components/Loader';
import ConfigPanel from '@/components/ConfigPanel';
import DownloadIcon from '@/components/icons/DownloadIcon';
import RetryIcon from '@/components/icons/RetryIcon';

const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

const formatBytes = (bytes: number, decimals = 2) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

const App: React.FC = () => {
  const [images, setImages] = useState<ImageFile[]>([]);
  const [keywordCount, setKeywordCount] = useState<number>(49);
  const [titleWordCount, setTitleWordCount] = useState<number>(15);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [globalError, setGlobalError] = useState<string | null>(null);
  const [imageToRetry, setImageToRetry] = useState<string | null>(null);

  const handleImageUpload = useCallback((files: File[]) => {
    const newImageFiles: ImageFile[] = files.map(file => ({
      id: crypto.randomUUID(),
      file,
      url: URL.createObjectURL(file),
      metadata: null,
      status: 'queued',
    }));
    setImages(prev => [...prev, ...newImageFiles]);
    setGlobalError(null);
  }, []);

  const processImages = useCallback(async (imagesToProcess: ImageFile[]) => {
    if (imagesToProcess.length === 0) {
      return;
    }
    setIsProcessing(true);

    for (let i = 0; i < imagesToProcess.length; i++) {
      const image = imagesToProcess[i];
      let success = false;
      let retries = 0;
      const MAX_RETRIES = 3;
      
      setImages(prev => prev.map(img => img.id === image.id ? { ...img, status: 'processing', error: undefined } : img));
      
      while(!success && retries < MAX_RETRIES) {
        try {
          const result = await generateImageMetadata(image.file, keywordCount, titleWordCount);
          setImages(prev => prev.map(img => img.id === image.id ? { ...img, metadata: result, status: 'completed' } : img));
          success = true;
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "An unknown error occurred.";
          if (errorMessage.includes('Rate limit exceeded')) {
            retries++;
            if (retries < MAX_RETRIES) {
              // Exponential backoff: 15s, 30s
              const backoff = 15000 * Math.pow(2, retries - 1);
              setImages(prev => prev.map(img => img.id === image.id ? { ...img, status: 'retrying', error: `Rate limit hit. Retrying in ${backoff/1000}s...`} : img));
              await delay(backoff);
              setImages(prev => prev.map(img => img.id === image.id ? { ...img, status: 'processing', error: undefined } : img));
            } else {
              setImages(prev => prev.map(img => img.id === image.id ? { ...img, status: 'error', error: "Rate limit exceeded after multiple retries." } : img));
            }
          } else {
            // Non-retriable error
            setImages(prev => prev.map(img => img.id === image.id ? { ...img, status: 'error', error: errorMessage } : img));
            break; // exit while loop
          }
        }
      }

      // Add a consistent, longer delay between processing *different* images to pace requests.
      if (i < imagesToProcess.length - 1) {
        await delay(12000);
      }
    }
    setIsProcessing(false);
  }, [keywordCount, titleWordCount]);


  const handleGenerateMetadata = useCallback(() => {
    const queuedImages = images.filter(img => img.status === 'queued' || img.status === 'error');
    if (queuedImages.length > 0) {
        processImages(queuedImages);
    }
  }, [images, processImages]);

  const handleRetry = (imageId: string) => {
    setImages(prev => prev.map(img => img.id === imageId ? { ...img, status: 'queued', error: undefined } : img));
    setImageToRetry(imageId);
  };
  
  useEffect(() => {
    if (imageToRetry) {
        const image = images.find(img => img.id === imageToRetry);
        if (image && image.status === 'queued' && !isProcessing) {
            processImages([image]);
        }
        setImageToRetry(null);
    }
  }, [imageToRetry, images, isProcessing, processImages]);

  const handleExportCsv = () => {
    const completedImages = images.filter(img => img.status === 'completed' && img.metadata);
    if (completedImages.length === 0) {
      alert("No completed metadata to export.");
      return;
    }
    
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "Filename,Title,Keywords\r\n";

    completedImages.forEach(image => {
        const filename = `"${image.file.name.replace(/"/g, '""')}"`;
        const title = `"${image.metadata!.title.replace(/"/g, '""')}"`;
        const keywords = `"${image.metadata!.keywords.join(', ')}"`;
        csvContent += [filename, title, keywords].join(',') + "\r\n";
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "image_metadata.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  const removeImage = (id: string) => {
    setImages(prev => prev.filter(img => img.id !== id));
  }

  return (
    <div className="min-h-screen font-sans text-gray-800">
      <header className="bg-white shadow-sm sticky top-0 z-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900">Adobe Stock Metadator</h1>
          <div className="flex items-center space-x-4">
             <button
              onClick={handleExportCsv}
              disabled={!images.some(img => img.status === 'completed')}
              className="flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition-colors"
            >
              <DownloadIcon className="w-5 h-5 mr-2" />
              Export CSV
            </button>
            <button
              onClick={handleGenerateMetadata}
              disabled={isProcessing || !images.some(img => ['queued', 'error'].includes(img.status))}
              className="flex items-center justify-center w-48 px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors"
            >
              {isProcessing ? <Loader /> : 'Generate All'}
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <section className="bg-white p-6 rounded-lg shadow animate-fade-in">
                <h2 className="text-xl font-semibold mb-4 text-gray-800">1. Upload Images</h2>
                <ImageUploader onImageUpload={handleImageUpload} />
            </section>
            
            {globalError && (
              <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-md animate-fade-in" role="alert">
                <p className="font-bold">Error</p>
                <p>{globalError}</p>
              </div>
            )}

            {images.length > 0 && (
                <section className="space-y-4 animate-slide-up">
                    <h2 className="text-xl font-semibold text-gray-800">2. Review & Generate</h2>
                    {images.map(image => (
                      <div key={image.id} className="bg-white rounded-lg shadow p-4 flex items-start space-x-4">
                        <img src={image.url} alt={image.file.name} className="w-32 h-32 object-cover rounded-md flex-shrink-0" />
                        <div className="flex-grow">
                          <div className="flex justify-between items-start">
                             <div>
                                <p className="font-semibold text-gray-800 truncate" title={image.file.name}>{image.file.name}</p>
                                <p className="text-sm text-gray-500">{formatBytes(image.file.size)}</p>
                              </div>
                            <button onClick={() => removeImage(image.id)} className="text-gray-400 hover:text-red-500 transition-colors p-1" aria-label="Remove image">
                              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                              </svg>
                            </button>
                          </div>
                          
                          <div className="mt-2">
                            {image.status === 'queued' && <div className="text-sm text-blue-600 font-medium">Ready to process</div>}
                            {image.status === 'processing' && <div className="flex items-center text-sm text-yellow-600 font-medium"><Loader /> <span className="ml-2">Generating...</span></div>}
                            {image.status === 'retrying' && <div className="flex items-center text-sm text-orange-600 font-medium"><Loader /> <span className="ml-2">{image.error}</span></div>}
                            {image.status === 'completed' && image.metadata && <MetadataDisplay metadata={image.metadata} />}
                            {image.status === 'error' && (
                                <div className="text-sm text-red-600 bg-red-50 p-3 rounded-md">
                                    <p className="font-bold break-words">Error: {image.error}</p>
                                    <button onClick={() => handleRetry(image.id)} disabled={isProcessing} className="mt-2 flex items-center text-sm font-semibold text-blue-600 hover:underline disabled:text-gray-400 disabled:cursor-not-allowed">
                                        <RetryIcon className="w-4 h-4 mr-1" />
                                        Retry
                                    </button>
                                </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                </section>
            )}
          </div>
          <aside className="lg:col-span-1">
            <div className="sticky top-28 space-y-8">
                <section className="bg-white p-6 rounded-lg shadow animate-fade-in">
                  <h2 className="text-xl font-semibold mb-4 text-gray-800">3. Configuration</h2>
                  <ConfigPanel 
                    keywordCount={keywordCount}
                    setKeywordCount={setKeywordCount}
                    titleWordCount={titleWordCount}
                    setTitleWordCount={setTitleWordCount}
                  />
                </section>
            </div>
          </aside>
        </div>
      </main>
    </div>
  );
};

export default App;
