export interface StockMetadata {
  title: string;
  keywords: string[];
}

export interface ImageFile {
    id: string;
    file: File;
    url: string;
    metadata: StockMetadata | null;
    status: 'queued' | 'processing' | 'completed' | 'error' | 'retrying';
    error?: string;
}