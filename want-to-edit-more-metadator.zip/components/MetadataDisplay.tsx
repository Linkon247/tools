import React, { useState, useCallback } from 'react';
import { StockMetadata } from '../types';
import CopyIcon from './icons/CopyIcon';
import CheckIcon from './icons/CheckIcon';

interface MetadataDisplayProps {
  metadata: StockMetadata;
}

const CopyButton: React.FC<{ textToCopy: string }> = ({ textToCopy }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = useCallback(() => {
    navigator.clipboard.writeText(textToCopy).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }, [textToCopy]);

  return (
    <button
      onClick={handleCopy}
      className="p-1.5 rounded-md bg-gray-100 hover:bg-gray-200 text-gray-500 hover:text-gray-700 transition-colors duration-200"
      aria-label="Copy to clipboard"
    >
      {copied ? <CheckIcon className="w-5 h-5 text-green-500" /> : <CopyIcon className="w-5 h-5" />}
    </button>
  );
};


const MetadataDisplay: React.FC<MetadataDisplayProps> = ({ metadata }) => {
  return (
    <div className="space-y-4 mt-4">
      <section>
        <div className="flex justify-between items-center mb-1">
          <h4 className="text-sm font-semibold text-gray-800">Title</h4>
          <CopyButton textToCopy={metadata.title} />
        </div>
        <p className="p-3 rounded-md bg-gray-100 text-gray-800 select-all text-sm border border-gray-200">{metadata.title}</p>
      </section>

      <section>
        <div className="flex justify-between items-center mb-1">
          <h4 className="text-sm font-semibold text-gray-800">Keywords</h4>
          <CopyButton textToCopy={metadata.keywords.join(', ')} />
        </div>
        <div className="p-3 rounded-md bg-gray-100 text-gray-800 text-sm border border-gray-200">
            <ul className="flex flex-wrap gap-2">
                {metadata.keywords.map((keyword, index) => (
                    <li key={index} className="px-2 py-1 bg-white rounded-md text-xs border border-gray-300 shadow-sm">
                        {keyword}
                    </li>
                ))}
            </ul>
        </div>
      </section>
    </div>
  );
};

export default MetadataDisplay;
