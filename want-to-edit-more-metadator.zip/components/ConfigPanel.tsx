
import React from 'react';

interface ConfigPanelProps {
    keywordCount: number;
    setKeywordCount: (count: number) => void;
    titleWordCount: number;
    setTitleWordCount: (count: number) => void;
}

const ConfigPanel: React.FC<ConfigPanelProps> = ({ keywordCount, setKeywordCount, titleWordCount, setTitleWordCount }) => {
  return (
    <div className="space-y-6">
      <div>
        <label htmlFor="keyword-count" className="block text-sm font-medium text-gray-600 mb-2 flex justify-between">
          <span>Keywords</span>
          <span className="font-bold text-gray-900">{keywordCount}</span>
        </label>
        <input
          id="keyword-count"
          type="range"
          min="5"
          max="49"
          value={keywordCount}
          onChange={(e) => setKeywordCount(Number(e.target.value))}
          className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer range-lg accent-blue-600"
        />
         <div className="flex justify-between text-xs text-gray-500 mt-1">
          <span>5</span>
          <span>49</span>
        </div>
      </div>
      <div>
        <label htmlFor="title-word-count" className="block text-sm font-medium text-gray-600 mb-2 flex justify-between">
          <span>Title Words</span>
           <span className="font-bold text-gray-900">{titleWordCount}</span>
        </label>
        <input
          id="title-word-count"
          type="range"
          min="5"
          max="25"
          value={titleWordCount}
          onChange={(e) => setTitleWordCount(Number(e.target.value))}
          className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer range-lg accent-blue-600"
        />
        <div className="flex justify-between text-xs text-gray-500 mt-1">
          <span>5</span>
          <span>25</span>
        </div>
      </div>
    </div>
  );
};

export default ConfigPanel;