import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import { StockMetadata } from '../types';

const fileToGenerativePart = async (file: File) => {
  const base64EncodedDataPromise = new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
    reader.readAsDataURL(file);
  });
  return {
    inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
  };
};

export const generateImageMetadata = async (imageFile: File, keywordCount: number, titleWordCount: number): Promise<StockMetadata> => {
  if (!process.env.API_KEY) {
    throw new Error("API Key is not configured. Cannot generate metadata.");
  }
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const imagePart = await fileToGenerativePart(imageFile);

  const userPrompt = `Generate metadata for this image.
- Title: a strict maximum of ${titleWordCount} words.
- Keywords: exactly ${keywordCount} keywords, ordered from most to least important. Keywords should include concepts, objects, colors, mood, and technical aspects (e.g., 'close-up', 'wide shot').`;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        parts: [imagePart, { text: userPrompt }],
      },
      config: {
        systemInstruction: "You are an expert in creating metadata for stock photography platforms like Adobe Stock. Analyze the provided image and generate a title and keywords. Return ONLY a valid JSON object matching the provided schema.",
        responseMimeType: "application/json",
        temperature: 0.4,
        responseSchema: {
            type: Type.OBJECT,
            properties: {
                title: {
                    type: Type.STRING,
                    description: `A concise, marketable title for the image with a strict maximum of ${titleWordCount} words.`
                },
                keywords: {
                    type: Type.ARRAY,
                    description: `An array of exactly ${keywordCount} relevant keywords, ordered by importance.`,
                    items: {
                        type: Type.STRING
                    }
                }
            },
            required: ['title', 'keywords']
        }
      }
    });
    
    const parsedData = JSON.parse(response.text) as StockMetadata;

    if (!parsedData.title || !Array.isArray(parsedData.keywords)) {
        throw new Error("Invalid metadata structure received from API.");
    }
    
    return parsedData;

  } catch (error) {
    console.error("Error generating metadata:", error);

    const errorString = JSON.stringify(error);
    if (errorString.includes('RESOURCE_EXHAUSTED') || errorString.includes('429')) {
      throw new Error("Rate limit exceeded. Please wait a moment and retry failed images.");
    }
    
    if (error instanceof Error) {
        // Handle malformed JSON response from the AI
        if (error.message.toLowerCase().includes('json') || error.message.includes('Unexpected token')) {
            throw new Error("AI returned an invalid response. Please try again.");
        }
        // Use the specific error message from the SDK
        throw new Error(error.message);
    }
    
    // Fallback for any other type of error
    throw new Error("An unknown error occurred during metadata generation.");
  }
};